create function lat_lon_distance(lat1 double precision, lon1 double precision, lat2 double precision, lon2 double precision) returns double precision
LANGUAGE plpgsql
AS $$
declare
  x float = 69.1 * (lat2 - lat1);
  y float = 69.1 * (lon2 - lon1) * cos(lat1 / 57.3);
begin
  return sqrt(x * x + y * y);
end
$$;
