CREATE MATERIALIZED VIEW fantasy_matview AS SELECT book.id,
    book.title,
    book.price,
    book.id_category,
    book.ratings,
    book.librarian
   FROM book
  WHERE (book.id_category = 1);
