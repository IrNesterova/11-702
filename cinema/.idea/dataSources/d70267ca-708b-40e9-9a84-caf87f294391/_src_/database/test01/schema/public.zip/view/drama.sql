CREATE VIEW drama AS SELECT book.id,
    book.title,
    book.price,
    book.id_category
   FROM book
  WHERE (book.id_category = 2)
WITH CASCADED CHECK OPTION;
