CREATE VIEW rowling AS SELECT bookauthors.id_book,
    bookauthors.id_author
   FROM bookauthors
  WHERE (bookauthors.id_author = 1)
WITH CASCADED CHECK OPTION;
