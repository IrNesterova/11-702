CREATE VIEW librarian_categories AS SELECT bookcategories.id,
    bookcategories.name,
    bookcategories.librarian
   FROM bookcategories
  WHERE ((bookcategories.librarian)::name = CURRENT_USER);
